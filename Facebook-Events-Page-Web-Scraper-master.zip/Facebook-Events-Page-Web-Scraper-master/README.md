# Facebook-Events-Page-Web-Scraper
Python Django Based Web App For Scraping Data From Facebook Events Pages (from multiple urls) to google spreadsheet and automatically saving data to firebase after manual checking


For more info check report.pdf in repository

Video tutorial : https://www.youtube.com/watch?v=fcIr9dGQBNw
